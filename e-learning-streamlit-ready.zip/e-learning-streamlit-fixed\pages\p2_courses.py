﻿<PASTE pages/p2_courses.py content here>
