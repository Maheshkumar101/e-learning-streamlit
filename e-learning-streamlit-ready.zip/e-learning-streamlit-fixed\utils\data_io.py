﻿<PASTE utils/data_io.py content here>
