﻿<PASTE utils/auth.py content here>
