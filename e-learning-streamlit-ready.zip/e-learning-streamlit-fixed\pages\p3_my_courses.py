﻿<PASTE pages/p3_my_courses.py content here>
